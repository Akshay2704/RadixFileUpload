const express = require("express");
const mail = require("../controllers/mail.controller");

const routerMail = express.Router();
routerMail.post("/", mail.sendMail);

module.exports = routerMail;
