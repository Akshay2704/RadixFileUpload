const express = require("express");
require("dotenv").config();
const transporter = require("../middleware/mail");

const sendMail = async (req, res) => {
  const mailOptions = {
    from: process.env.MAIL_USER,
    to: req.body.sender,
    subject: req.body.subject,
    text: req.body.text,
  };
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
    } else {
      res.status(200).send("Email send");
      console.log("Email sent: " + info.response);
    }
  });
};

module.exports.sendMail = sendMail;
